# Mode Opératoire d'Installation
## ORBITE ZÉRO - Guide d'Installation Complet

---

## Table des matières
1. [Prérequis système](#1-prérequis-système)
2. [Installation de Python](#2-installation-de-python)
3. [Installation des dépendances](#3-installation-des-dépendances)
4. [Configuration du projet](#4-configuration-du-projet)
5. [Lancement du jeu](#5-lancement-du-jeu)
6. [Résolution des problèmes](#6-résolution-des-problèmes)

---

## 1. Prérequis système

### Configuration minimale requise

| Composant | Minimum | Recommandé |
|-----------|---------|------------|
| Système d'exploitation | Windows 10 | Windows 10/11 |
| Processeur | Intel Core i3 / AMD Ryzen 3 | Intel Core i5 / AMD Ryzen 5 |
| Mémoire RAM | 4 Go | 8 Go |
| Espace disque | 500 Mo | 1 Go |
| Carte graphique | Intégrée | Dédiée avec OpenGL 3.0+ |
| Connexion réseau | LAN 100 Mbps | LAN Gigabit |

### Logiciels requis
- Python 3.10 ou supérieur
- PyGame 2.5 ou supérieur
- Git (pour les développeurs)

---

## 2. Installation de Python

### 2.1 Téléchargement

1. Rendez-vous sur le site officiel : https://www.python.org/downloads/
2. Cliquez sur "Download Python 3.12.x" (ou version supérieure)
3. Téléchargez l'installateur Windows (64 bits recommandé)

### 2.2 Installation

1. Lancez l'installateur téléchargé

2. **IMPORTANT** : Cochez la case **"Add Python to PATH"** en bas de la fenêtre

3. Cliquez sur **"Install Now"** pour une installation standard
   
   OU
   
   Cliquez sur **"Customize installation"** pour choisir les options :
   - Cochez toutes les options dans "Optional Features"
   - Dans "Advanced Options", cochez :
     - "Install for all users"
     - "Add Python to environment variables"
   - Cliquez sur "Install"

4. Attendez la fin de l'installation

5. Cliquez sur "Close"

### 2.3 Vérification de l'installation

Ouvrez une invite de commandes (cmd) ou PowerShell et tapez :

```bash
python --version
```

Vous devriez voir : `Python 3.12.x`

Vérifiez également pip :

```bash
pip --version
```

Vous devriez voir : `pip 23.x.x from ...`

---

## 3. Installation des dépendances

### 3.1 Mise à jour de pip

Avant d'installer les dépendances, mettez à jour pip :

```bash
python -m pip install --upgrade pip
```

### 3.2 Installation de PyGame

PyGame est le framework graphique utilisé pour le jeu.

```bash
pip install pygame
```

Vérification :
```bash
python -c "import pygame; print(pygame.version.ver)"
```

### 3.3 Création du fichier requirements.txt

Pour faciliter l'installation, créez un fichier `requirements.txt` à la racine du projet :

```
pygame>=2.5.0
```

Installation via requirements.txt :
```bash
pip install -r requirements.txt
```

### 3.4 Installation des dépendances supplémentaires (optionnel)

Pour les fonctionnalités avancées :

```bash
# Pour le réseau (inclus dans Python par défaut)
# socket et threading sont des modules standard

# Pour le débogage (optionnel)
pip install pygame-ce  # Version communautaire de PyGame (alternative)
```

---

## 4. Configuration du projet

### 4.1 Structure des dossiers

Assurez-vous que le projet a la structure suivante :

```
orbite_zero/
│
├── src/                    # Code source Python
│   ├── main.py            # Point d'entrée du jeu
│   ├── config.py          # Configuration
│   ├── structures_donnees.py
│   ├── audio.py
│   ├── reseau.py
│   └── interface.py
│
├── assets/                 # Ressources du jeu
│   ├── sounds/            # Fichiers audio
│   ├── images/            # Images et sprites
│   └── fonts/             # Polices de caractères
│
├── data/                   # Données de sauvegarde
│
├── docs/                   # Documentation
│
└── requirements.txt        # Dépendances Python
```

### 4.2 Configuration des chemins

Le fichier `config.py` contient les chemins par défaut :

```python
CHEMIN_IMAGES = "assets/images/"
CHEMIN_SONS = "assets/sounds/"
CHEMIN_POLICES = "assets/fonts/"
CHEMIN_DONNEES = "data/"
```

Si vous déplacez le projet, ces chemins sont relatifs et devraient fonctionner.

### 4.3 Création des dossiers manquants

Si les dossiers n'existent pas, créez-les :

```bash
mkdir assets
mkdir assets\sounds
mkdir assets\images
mkdir assets\fonts
mkdir data
```

Ou sur PowerShell :
```powershell
New-Item -ItemType Directory -Force -Path assets\sounds, assets\images, assets\fonts, data
```

---

## 5. Lancement du jeu

### 5.1 Méthode simple (recommandée)

1. Ouvrez un terminal (cmd, PowerShell, ou Git Bash)

2. Naviguez vers le dossier du projet :
```bash
cd chemin\vers\orbite_zero
```

3. Lancez le jeu :
```bash
python src/main.py
```

### 5.2 Création d'un raccourci

Pour faciliter le lancement, créez un fichier batch `lancer_jeu.bat` :

```batch
@echo off
cd /d %~dp0
python src/main.py
pause
```

Double-cliquez sur ce fichier pour lancer le jeu.

### 5.3 Mode multijoueur LAN

#### Joueur 1 (Hôte) :
1. Lancez le jeu
2. Cliquez sur "Nouvelle Partie"
3. Configurez votre personnage
4. Notez l'adresse IP affichée (ex: 192.168.1.100)
5. Attendez la connexion du joueur 2

#### Joueur 2 (Client) :
1. Lancez le jeu sur un autre ordinateur du même réseau
2. Cliquez sur "Rejoindre une Partie"
3. Configurez votre personnage
4. Le jeu tentera de se connecter automatiquement (localhost par défaut)

**Note** : Pour rejoindre un autre ordinateur, modifiez l'adresse dans le code ou utilisez la version avec saisie d'adresse IP.

---

## 6. Résolution des problèmes

### 6.1 "Python n'est pas reconnu comme commande"

**Cause** : Python n'est pas dans le PATH système.

**Solution** :
1. Réinstallez Python en cochant "Add Python to PATH"
2. OU ajoutez manuellement Python au PATH :
   - Recherchez "Variables d'environnement" dans Windows
   - Modifiez la variable PATH
   - Ajoutez le chemin vers Python (ex: `C:\Users\VotreNom\AppData\Local\Programs\Python\Python312`)

### 6.2 "No module named 'pygame'"

**Cause** : PyGame n'est pas installé.

**Solution** :
```bash
pip install pygame
```

Si pip n'est pas reconnu :
```bash
python -m pip install pygame
```

### 6.3 Écran noir au lancement

**Causes possibles** :
- Pilotes graphiques obsolètes
- Problème de compatibilité OpenGL

**Solutions** :
1. Mettez à jour vos pilotes graphiques
2. Essayez de lancer en mode fenêtré (déjà le cas par défaut)
3. Vérifiez que PyGame est bien installé

### 6.4 Le son ne fonctionne pas

**Causes possibles** :
- Fichiers audio manquants
- Périphérique audio non détecté

**Solutions** :
1. Vérifiez que le dossier `assets/sounds/` existe
2. Le jeu fonctionne sans fichiers audio (fonctionnalité dégradée)
3. Vérifiez les paramètres audio de Windows

### 6.5 Erreur de connexion réseau

**Causes possibles** :
- Pare-feu bloquant le port
- Ordinateurs pas sur le même réseau

**Solutions** :
1. Autorisez Python dans le pare-feu Windows :
   - Panneau de configuration → Pare-feu Windows
   - Autoriser une application → Python
2. Vérifiez que les deux ordinateurs sont sur le même réseau local
3. Désactivez temporairement le pare-feu pour tester

### 6.6 Le jeu plante au démarrage

**Solution de diagnostic** :
```bash
python -c "import pygame; pygame.init(); print('PyGame OK')"
```

Si cette commande échoue, réinstallez PyGame :
```bash
pip uninstall pygame
pip install pygame
```

---

## 7. Informations pour le développement

### 7.1 Environnement virtuel (recommandé pour les développeurs)

Créer un environnement virtuel :
```bash
python -m venv venv
```

Activer l'environnement :
```bash
# Windows (cmd)
venv\Scripts\activate

# Windows (PowerShell)
.\venv\Scripts\Activate.ps1

# Linux/Mac
source venv/bin/activate
```

Installer les dépendances dans l'environnement :
```bash
pip install -r requirements.txt
```

### 7.2 Exécution des tests

Pour tester les modules individuellement :

```bash
# Test des structures de données
python src/structures_donnees.py

# Test du module audio
python src/audio.py

# Test du module réseau
python src/reseau.py
```

---

## 8. Désinstallation

### 8.1 Supprimer le jeu

Supprimez simplement le dossier `orbite_zero`.

### 8.2 Supprimer PyGame

```bash
pip uninstall pygame
```

### 8.3 Supprimer Python

Utilisez "Ajouter ou supprimer des programmes" dans Windows.

---

## Contact et support

En cas de problème non résolu, contactez l'équipe :

- **Chef de projet** : Ilian Drouin
- **Email** : ilian.drouin@epita.fr

---

*Document rédigé par l'équipe Relentless Five*
*EPITA - Classe B1.1 - Janvier 2026*
