# Mode Opératoire Git
## Projet ORBITE ZÉRO - Équipe Relentless Five

---

## 1. Introduction à Git

Git est un système de gestion de versions qui permet à plusieurs développeurs de travailler ensemble sur le même projet. Il garde un historique de toutes les modifications et permet de revenir en arrière si nécessaire.

### Vocabulaire de base
- **Repository (dépôt)** : Dossier contenant votre projet et son historique
- **Commit** : Sauvegarde d'une version de vos fichiers
- **Branch (branche)** : Version parallèle du projet pour travailler sans perturber le code principal
- **Pull** : Récupérer les modifications depuis le serveur
- **Push** : Envoyer vos modifications vers le serveur
- **Merge** : Fusionner deux branches

---

## 2. Installation de Git

### Sur Windows
1. Téléchargez Git depuis : https://git-scm.com/download/windows
2. Lancez l'installateur
3. Cliquez sur "Next" pour toutes les options par défaut
4. À la fin, cochez "Launch Git Bash"

### Vérification de l'installation
Ouvrez un terminal (Git Bash sur Windows) et tapez :
```bash
git --version
```
Vous devriez voir quelque chose comme : `git version 2.xx.x`

---

## 3. Configuration initiale (À FAIRE UNE SEULE FOIS)

Configurez votre identité Git. Remplacez par vos informations :

```bash
# Configuration du nom (utilisez votre vrai nom)
git config --global user.name "Ilian Drouin"

# Configuration de l'email (utilisez votre email EPITA)
git config --global user.email "ilian.drouin@epita.fr"

# Configuration de l'éditeur par défaut (optionnel)
git config --global core.editor "notepad"

# Vérification de la configuration
git config --list
```

---

## 4. Création du dépôt Git pour le projet

### 4.1 Initialisation du dépôt local

Ouvrez un terminal dans le dossier du projet et tapez :

```bash
# Se placer dans le dossier du projet
cd chemin/vers/orbite_zero

# Initialiser le dépôt Git
git init

# Vérifier que le dépôt est créé
git status
```

### 4.2 Création du fichier .gitignore

Créez un fichier `.gitignore` à la racine du projet pour ignorer certains fichiers :

```bash
# Créer et éditer le fichier .gitignore
notepad .gitignore
```

Contenu du fichier `.gitignore` :
```
# Fichiers Python compilés
__pycache__/
*.py[cod]
*$py.class
*.pyc

# Environnements virtuels
venv/
env/
.env

# Fichiers de configuration IDE
.idea/
.vscode/
*.swp
*.swo

# Fichiers de sauvegarde
data/*.json
*.bak

# Fichiers système
.DS_Store
Thumbs.db

# Logs
*.log

# Fichiers temporaires
*.tmp
temp/
```

### 4.3 Premier commit

```bash
# Ajouter tous les fichiers au suivi Git
git add .

# Vérifier les fichiers ajoutés
git status

# Créer le premier commit
git commit -m "Initial commit - Structure du projet Orbite Zero"
```

---

## 5. Structure des branches recommandée

Pour travailler en équipe, nous utilisons plusieurs branches :

```
main (ou master)
  │
  ├── develop
  │     │
  │     ├── feature/menu-principal
  │     ├── feature/creation-joueur
  │     ├── feature/reseau-multijoueur
  │     └── feature/audio
  │
  └── release/v1.0
```

### Création des branches

```bash
# Créer et se déplacer sur la branche develop
git checkout -b develop

# Créer une branche pour une fonctionnalité
git checkout -b feature/menu-principal

# Revenir sur develop
git checkout develop

# Voir toutes les branches
git branch -a
```

---

## 6. Workflow quotidien

### 6.1 Avant de commencer à travailler

```bash
# 1. Se placer sur develop
git checkout develop

# 2. Récupérer les dernières modifications
git pull origin develop

# 3. Créer ou se placer sur sa branche de fonctionnalité
git checkout feature/ma-fonctionnalite
# OU créer une nouvelle branche
git checkout -b feature/nouvelle-fonctionnalite
```

### 6.2 Pendant le travail

```bash
# Voir les fichiers modifiés
git status

# Voir les différences
git diff

# Ajouter des fichiers spécifiques
git add src/fichier_modifie.py

# OU ajouter tous les fichiers modifiés
git add .

# Créer un commit avec un message descriptif
git commit -m "Description claire de ce qui a été fait"
```

### 6.3 Messages de commit - Bonnes pratiques

Format recommandé :
```
[TYPE] Description courte (max 50 caractères)

Description détaillée si nécessaire (optionnel)
```

Types de commit :
- `[ADD]` : Ajout d'une nouvelle fonctionnalité
- `[FIX]` : Correction d'un bug
- `[UPDATE]` : Mise à jour d'une fonctionnalité existante
- `[REFACTOR]` : Refactorisation du code (sans changer le comportement)
- `[DOC]` : Ajout ou modification de documentation
- `[STYLE]` : Modifications de mise en forme

Exemples :
```bash
git commit -m "[ADD] Menu principal avec navigation clavier/souris"
git commit -m "[FIX] Correction du bug de déplacement du joueur"
git commit -m "[UPDATE] Amélioration des effets sonores du menu"
git commit -m "[DOC] Ajout des commentaires dans config.py"
```

### 6.4 Envoyer les modifications

```bash
# Envoyer sur le serveur distant
git push origin feature/ma-fonctionnalite
```

### 6.5 Fusionner une fonctionnalité terminée

```bash
# 1. Se placer sur develop
git checkout develop

# 2. Récupérer les dernières modifications
git pull origin develop

# 3. Fusionner la branche de fonctionnalité
git merge feature/ma-fonctionnalite

# 4. Envoyer les modifications
git push origin develop

# 5. (Optionnel) Supprimer la branche locale
git branch -d feature/ma-fonctionnalite
```

---

## 7. Gestion des conflits

Un conflit survient quand deux personnes modifient la même ligne de code.

### 7.1 Quand un conflit apparaît

Git vous affichera :
```
CONFLICT (content): Merge conflict in src/fichier.py
Automatic merge failed; fix conflicts and then commit the result.
```

### 7.2 Résolution du conflit

1. Ouvrez le fichier en conflit
2. Cherchez les marqueurs de conflit :
```python
<<<<<<< HEAD
# Votre version du code
print("Version locale")
=======
# Version du serveur
print("Version distante")
>>>>>>> branch-name
```

3. Choisissez quelle version garder (ou combinez-les)
4. Supprimez les marqueurs `<<<<<<<`, `=======`, `>>>>>>>`
5. Sauvegardez le fichier

### 7.3 Finaliser la résolution

```bash
# Marquer le conflit comme résolu
git add src/fichier.py

# Terminer le merge
git commit -m "[FIX] Résolution du conflit dans fichier.py"

# Envoyer
git push origin develop
```

---

## 8. Commandes utiles

### Voir l'historique
```bash
# Historique simple
git log --oneline

# Historique détaillé
git log

# Historique avec graphique des branches
git log --oneline --graph --all
```

### Annuler des modifications
```bash
# Annuler les modifications d'un fichier non commité
git checkout -- src/fichier.py

# Annuler le dernier commit (garde les modifications)
git reset --soft HEAD~1

# Annuler le dernier commit (supprime les modifications)
git reset --hard HEAD~1
```

### Sauvegarder temporairement son travail
```bash
# Mettre de côté les modifications en cours
git stash

# Récupérer les modifications mises de côté
git stash pop

# Voir la liste des stash
git stash list
```

---

## 9. Configuration du dépôt distant (GitHub/GitLab)

### 9.1 Créer un compte et un dépôt
1. Créez un compte sur GitHub (github.com) ou GitLab
2. Créez un nouveau repository "orbite-zero"
3. Ne cochez pas "Initialize with README"

### 9.2 Lier le dépôt local au dépôt distant

```bash
# Ajouter l'URL du dépôt distant
git remote add origin https://github.com/votre-username/orbite-zero.git

# Vérifier la configuration
git remote -v

# Premier push (envoie la branche main)
git push -u origin main

# Envoyer également la branche develop
git checkout develop
git push -u origin develop
```

---

## 10. Répartition des branches par membre

| Membre | Branche principale |
|--------|-------------------|
| Ilian Drouin | `feature/menu-principal`, `feature/tests` |
| Samy El-Alaoui | `feature/site-internet`, `feature/IA` |
| Ahmed Shanan | `feature/mecanique-jeu`, `feature/effets-sonores` |
| Louis Murail | `feature/multijoueur`, `feature/design` |
| Melvyn Tchatchou | `feature/design`, `feature/mecaniques` |

---

## 11. Checklist avant chaque soutenance

- [ ] Tous les membres ont pushé leurs modifications
- [ ] La branche `develop` est à jour
- [ ] Fusion de `develop` dans `main` pour la version stable
- [ ] Tag de version créé : `git tag -a v1.0 -m "Version soutenance 1"`
- [ ] Le code compile et s'exécute sans erreur
- [ ] Tous les tests passent

---

## 12. En cas de problème

### Le push est refusé
```bash
# Récupérer d'abord les modifications distantes
git pull origin nom-de-branche

# Puis réessayer le push
git push origin nom-de-branche
```

### Je me suis trompé de branche
```bash
# Voir sur quelle branche on est
git branch

# Changer de branche (attention aux modifications non commitées)
git checkout bonne-branche
```

### J'ai fait des modifications sur la mauvaise branche
```bash
# Sauvegarder les modifications
git stash

# Changer de branche
git checkout bonne-branche

# Récupérer les modifications
git stash pop
```

---

## Support

En cas de difficulté, consultez :
- Documentation officielle Git : https://git-scm.com/doc
- GitHub Guides : https://guides.github.com/
- Votre responsable de projet (Ilian Drouin)

---

*Document rédigé par l'équipe Relentless Five - Janvier 2026*
