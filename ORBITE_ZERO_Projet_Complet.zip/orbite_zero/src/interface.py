"""
=============================================================================
Module d'interface utilisateur - ORBITE ZÉRO
=============================================================================
Ce module gère tous les éléments d'interface : menus, boutons, écrans
de chargement, et affichage du HUD (Head-Up Display).

L'interface utilise PyGame pour le rendu graphique et offre une
expérience utilisateur cohérente avec le thème spatial du jeu.

Auteurs: Équipe Relentless Five
Date: Janvier 2026
Version: 1.0 - Première soutenance
=============================================================================
"""

import pygame
import math
from config import *


class Bouton:
    """
    Classe représentant un bouton interactif.
    
    Un bouton peut être cliqué à la souris ou sélectionné au clavier.
    Il change d'apparence au survol et lors de la sélection.
    
    Attributs:
        rect (pygame.Rect): Zone cliquable du bouton
        texte (str): Texte affiché sur le bouton
        est_selectionne (bool): True si le bouton est sélectionné
        est_survole (bool): True si la souris survole le bouton
    """
    
    def __init__(self, x, y, largeur, hauteur, texte, taille_police=TAILLE_POLICE_MENU):
        """
        Initialise un bouton.
        
        Arguments:
            x (int): Position X du centre du bouton
            y (int): Position Y du centre du bouton
            largeur (int): Largeur du bouton
            hauteur (int): Hauteur du bouton
            texte (str): Texte à afficher
            taille_police (int): Taille de la police
        """
        # Rectangle du bouton (centré sur x, y)
        self.rect = pygame.Rect(0, 0, largeur, hauteur)
        self.rect.center = (x, y)
        
        # Texte
        self.texte = texte
        self.taille_police = taille_police
        self.police = pygame.font.Font(None, taille_police)
        
        # États
        self.est_selectionne = False
        self.est_survole = False
        self.est_actif = True  # False = bouton désactivé
        
        # Couleurs
        self.couleur_normale = GRIS_FONCE
        self.couleur_survol = ORANGE_ACCENT
        self.couleur_selection = ORANGE_CLAIR
        self.couleur_texte = BLANC
        self.couleur_texte_inactif = GRIS
        
        # Animation
        self.animation_alpha = 0
        
    def mettre_a_jour(self, position_souris):
        """
        Met à jour l'état du bouton selon la position de la souris.
        
        Arguments:
            position_souris (tuple): Position (x, y) de la souris
        """
        if self.est_actif:
            self.est_survole = self.rect.collidepoint(position_souris)
    
    def est_clique(self, position_souris, bouton_presse):
        """
        Vérifie si le bouton est cliqué.
        
        Arguments:
            position_souris (tuple): Position de la souris
            bouton_presse (bool): True si le bouton gauche est pressé
        
        Retourne:
            bool: True si le bouton est cliqué
        """
        if self.est_actif and bouton_presse:
            return self.rect.collidepoint(position_souris)
        return False
    
    def dessiner(self, surface):
        """
        Dessine le bouton sur la surface.
        
        Arguments:
            surface (pygame.Surface): Surface de destination
        """
        # Choix de la couleur selon l'état
        if not self.est_actif:
            couleur = GRIS_FONCE
        elif self.est_selectionne:
            couleur = self.couleur_selection
        elif self.est_survole:
            couleur = self.couleur_survol
        else:
            couleur = self.couleur_normale
        
        # Dessin du fond du bouton avec bordure arrondie
        pygame.draw.rect(surface, couleur, self.rect, border_radius=8)
        
        # Bordure
        bordure_couleur = ORANGE_ACCENT if (self.est_selectionne or self.est_survole) else GRIS
        pygame.draw.rect(surface, bordure_couleur, self.rect, 2, border_radius=8)
        
        # Texte
        couleur_texte = self.couleur_texte if self.est_actif else self.couleur_texte_inactif
        texte_surface = self.police.render(self.texte, True, couleur_texte)
        texte_rect = texte_surface.get_rect(center=self.rect.center)
        surface.blit(texte_surface, texte_rect)


class ChampTexte:
    """
    Classe représentant un champ de saisie de texte.
    
    Permet à l'utilisateur d'entrer du texte (nom du joueur, adresse IP...).
    
    Attributs:
        rect (pygame.Rect): Zone du champ
        texte (str): Texte saisi
        est_actif (bool): True si le champ est sélectionné pour la saisie
    """
    
    def __init__(self, x, y, largeur, hauteur, placeholder="", max_caracteres=20):
        """
        Initialise un champ de texte.
        
        Arguments:
            x (int): Position X
            y (int): Position Y
            largeur (int): Largeur du champ
            hauteur (int): Hauteur du champ
            placeholder (str): Texte affiché quand le champ est vide
            max_caracteres (int): Nombre maximum de caractères
        """
        self.rect = pygame.Rect(x, y, largeur, hauteur)
        self.texte = ""
        self.placeholder = placeholder
        self.max_caracteres = max_caracteres
        
        # Police
        self.police = pygame.font.Font(None, TAILLE_POLICE_MENU)
        
        # États
        self.est_actif = False
        
        # Curseur clignotant
        self.curseur_visible = True
        self.temps_curseur = 0
        self.delai_curseur = 500  # millisecondes
        
        # Couleurs
        self.couleur_fond = GRIS_FONCE
        self.couleur_bordure = GRIS
        self.couleur_bordure_active = ORANGE_ACCENT
        self.couleur_texte = BLANC
        self.couleur_placeholder = GRIS
    
    def gerer_evenement(self, evenement):
        """
        Gère les événements clavier pour la saisie.
        
        Arguments:
            evenement (pygame.event): Événement PyGame
        """
        if not self.est_actif:
            return
        
        if evenement.type == pygame.KEYDOWN:
            if evenement.key == pygame.K_BACKSPACE:
                # Suppression du dernier caractère
                self.texte = self.texte[:-1]
            elif evenement.key == pygame.K_RETURN:
                # Désactivation du champ
                self.est_actif = False
            elif len(self.texte) < self.max_caracteres:
                # Ajout du caractère (si imprimable)
                if evenement.unicode.isprintable():
                    self.texte += evenement.unicode
    
    def mettre_a_jour(self, position_souris, clic):
        """
        Met à jour l'état du champ selon les clics souris.
        
        Arguments:
            position_souris (tuple): Position de la souris
            clic (bool): True si clic gauche
        """
        if clic:
            self.est_actif = self.rect.collidepoint(position_souris)
        
        # Animation du curseur
        temps_actuel = pygame.time.get_ticks()
        if temps_actuel - self.temps_curseur > self.delai_curseur:
            self.curseur_visible = not self.curseur_visible
            self.temps_curseur = temps_actuel
    
    def dessiner(self, surface):
        """
        Dessine le champ de texte.
        
        Arguments:
            surface (pygame.Surface): Surface de destination
        """
        # Fond
        pygame.draw.rect(surface, self.couleur_fond, self.rect, border_radius=5)
        
        # Bordure
        bordure_couleur = self.couleur_bordure_active if self.est_actif else self.couleur_bordure
        pygame.draw.rect(surface, bordure_couleur, self.rect, 2, border_radius=5)
        
        # Texte ou placeholder
        if self.texte:
            texte_affiche = self.texte
            couleur = self.couleur_texte
        else:
            texte_affiche = self.placeholder
            couleur = self.couleur_placeholder
        
        texte_surface = self.police.render(texte_affiche, True, couleur)
        texte_rect = texte_surface.get_rect(midleft=(self.rect.x + 10, self.rect.centery))
        surface.blit(texte_surface, texte_rect)
        
        # Curseur clignotant
        if self.est_actif and self.curseur_visible:
            curseur_x = texte_rect.right + 2 if self.texte else self.rect.x + 10
            pygame.draw.line(surface, BLANC, 
                           (curseur_x, self.rect.y + 10),
                           (curseur_x, self.rect.bottom - 10), 2)


class Menu:
    """
    Classe de base pour les menus du jeu.
    
    Cette classe gère une liste de boutons et la navigation
    au clavier et à la souris.
    
    Attributs:
        boutons (list): Liste des boutons du menu
        index_selection (int): Index du bouton actuellement sélectionné
    """
    
    def __init__(self):
        """
        Initialise le menu.
        """
        self.boutons = []
        self.index_selection = 0
        self.titre = ""
        self.sous_titre = ""
    
    def ajouter_bouton(self, bouton):
        """
        Ajoute un bouton au menu.
        
        Arguments:
            bouton (Bouton): Bouton à ajouter
        """
        self.boutons.append(bouton)
        if len(self.boutons) == 1:
            self.boutons[0].est_selectionne = True
    
    def naviguer(self, direction):
        """
        Change la sélection du bouton.
        
        Arguments:
            direction (int): 1 pour bas, -1 pour haut
        """
        if not self.boutons:
            return
        
        # Désélection du bouton actuel
        self.boutons[self.index_selection].est_selectionne = False
        
        # Calcul du nouvel index
        self.index_selection = (self.index_selection + direction) % len(self.boutons)
        
        # Sélection du nouveau bouton
        self.boutons[self.index_selection].est_selectionne = True
    
    def obtenir_selection(self):
        """
        Retourne l'index du bouton sélectionné.
        
        Retourne:
            int: Index du bouton sélectionné
        """
        return self.index_selection
    
    def mettre_a_jour(self, position_souris, clic):
        """
        Met à jour tous les boutons du menu.
        
        Arguments:
            position_souris (tuple): Position de la souris
            clic (bool): True si clic gauche
        
        Retourne:
            int ou None: Index du bouton cliqué ou None
        """
        for i, bouton in enumerate(self.boutons):
            bouton.mettre_a_jour(position_souris)
            
            if clic and bouton.est_clique(position_souris, clic):
                return i
        
        return None
    
    def dessiner(self, surface):
        """
        Dessine tous les boutons du menu.
        
        Arguments:
            surface (pygame.Surface): Surface de destination
        """
        for bouton in self.boutons:
            bouton.dessiner(surface)


class MenuPrincipal(Menu):
    """
    Menu principal du jeu avec les options de base.
    """
    
    def __init__(self):
        """
        Initialise le menu principal.
        """
        super().__init__()
        
        self.titre = "ORBITE ZÉRO"
        self.sous_titre = "Sauvez la Terre avant qu'il ne soit trop tard..."
        
        # Position centrale
        centre_x = LARGEUR_FENETRE // 2
        debut_y = 350
        
        # Création des boutons
        boutons_config = [
            "Nouvelle Partie",
            "Rejoindre une Partie",
            "Options",
            "Quitter"
        ]
        
        for i, texte in enumerate(boutons_config):
            bouton = Bouton(centre_x, debut_y + i * 70, 300, 50, texte)
            self.ajouter_bouton(bouton)
    
    def dessiner_fond(self, surface):
        """
        Dessine le fond animé et le titre du menu.
        
        Arguments:
            surface (pygame.Surface): Surface de destination
        """
        # Fond spatial
        surface.fill(BLEU_ESPACE)
        
        # Étoiles simples (positions fixes pour l'instant)
        for i in range(50):
            x = (i * 73) % LARGEUR_FENETRE
            y = (i * 47) % HAUTEUR_FENETRE
            taille = 1 + (i % 3)
            pygame.draw.circle(surface, BLANC, (x, y), taille)
        
        # Titre
        police_titre = pygame.font.Font(None, TAILLE_POLICE_TITRE)
        titre_surface = police_titre.render(self.titre, True, ORANGE_ACCENT)
        titre_rect = titre_surface.get_rect(center=(LARGEUR_FENETRE // 2, 150))
        surface.blit(titre_surface, titre_rect)
        
        # Sous-titre
        police_sous_titre = pygame.font.Font(None, TAILLE_POLICE_SOUS_TITRE)
        sous_titre_surface = police_sous_titre.render(self.sous_titre, True, GRIS_CLAIR)
        sous_titre_rect = sous_titre_surface.get_rect(center=(LARGEUR_FENETRE // 2, 220))
        surface.blit(sous_titre_surface, sous_titre_rect)


class EcranCreationJoueur:
    """
    Écran de création/configuration du joueur.
    
    Permet au joueur d'entrer son nom et de choisir son rôle.
    """
    
    def __init__(self, numero_joueur=1):
        """
        Initialise l'écran de création de joueur.
        
        Arguments:
            numero_joueur (int): 1 ou 2
        """
        self.numero_joueur = numero_joueur
        
        # Titre
        self.titre = f"Configuration du Joueur {numero_joueur}"
        
        # Champ de nom
        self.champ_nom = ChampTexte(
            LARGEUR_FENETRE // 2 - 150, 250,
            300, 50,
            placeholder="Entrez votre nom"
        )
        
        # Boutons de rôle
        self.role_selectionne = None
        centre_x = LARGEUR_FENETRE // 2
        
        self.bouton_concepteur = Bouton(
            centre_x - 170, 380, 300, 60,
            "Le Concepteur", TAILLE_POLICE_PETIT
        )
        self.bouton_pragmatique = Bouton(
            centre_x + 170, 380, 300, 60,
            "Le Pragmatique", TAILLE_POLICE_PETIT
        )
        
        # Descriptions des rôles
        self.desc_concepteur = "Créateur du système AGERIS, expert en technologie"
        self.desc_pragmatique = "Expert en maintenance, méfiant envers la technologie"
        
        # Bouton de validation
        self.bouton_valider = Bouton(
            centre_x, 550, 250, 50,
            "Valider"
        )
        self.bouton_valider.est_actif = False
        
        # Bouton retour
        self.bouton_retour = Bouton(
            100, 50, 150, 40,
            "← Retour", TAILLE_POLICE_PETIT
        )
    
    def mettre_a_jour(self, position_souris, clic, evenement=None):
        """
        Met à jour l'écran de création.
        
        Arguments:
            position_souris (tuple): Position de la souris
            clic (bool): True si clic gauche
            evenement: Événement PyGame pour la saisie
        
        Retourne:
            str ou None: Action à effectuer ("retour", "valider") ou None
        """
        # Mise à jour du champ de texte
        self.champ_nom.mettre_a_jour(position_souris, clic)
        
        if evenement:
            self.champ_nom.gerer_evenement(evenement)
        
        # Mise à jour des boutons de rôle
        self.bouton_concepteur.mettre_a_jour(position_souris)
        self.bouton_pragmatique.mettre_a_jour(position_souris)
        
        if clic:
            if self.bouton_concepteur.est_clique(position_souris, clic):
                self.role_selectionne = "Concepteur"
                self.bouton_concepteur.est_selectionne = True
                self.bouton_pragmatique.est_selectionne = False
            
            elif self.bouton_pragmatique.est_clique(position_souris, clic):
                self.role_selectionne = "Pragmatique"
                self.bouton_pragmatique.est_selectionne = True
                self.bouton_concepteur.est_selectionne = False
        
        # Activation du bouton valider si les infos sont complètes
        self.bouton_valider.est_actif = (
            len(self.champ_nom.texte) >= 2 and 
            self.role_selectionne is not None
        )
        
        # Mise à jour des boutons
        self.bouton_valider.mettre_a_jour(position_souris)
        self.bouton_retour.mettre_a_jour(position_souris)
        
        # Détection des clics
        if clic:
            if self.bouton_retour.est_clique(position_souris, clic):
                return "retour"
            if self.bouton_valider.est_clique(position_souris, clic):
                return "valider"
        
        return None
    
    def obtenir_donnees_joueur(self):
        """
        Retourne les données saisies par le joueur.
        
        Retourne:
            dict: Dictionnaire avec nom et rôle
        """
        return {
            "nom": self.champ_nom.texte,
            "role": self.role_selectionne
        }
    
    def dessiner(self, surface):
        """
        Dessine l'écran de création.
        
        Arguments:
            surface (pygame.Surface): Surface de destination
        """
        # Fond
        surface.fill(BLEU_ESPACE)
        
        # Titre
        police_titre = pygame.font.Font(None, TAILLE_POLICE_TITRE)
        titre_surface = police_titre.render(self.titre, True, ORANGE_ACCENT)
        titre_rect = titre_surface.get_rect(center=(LARGEUR_FENETRE // 2, 80))
        surface.blit(titre_surface, titre_rect)
        
        # Label pour le nom
        police_label = pygame.font.Font(None, TAILLE_POLICE_PETIT)
        label_nom = police_label.render("Votre nom:", True, BLANC)
        surface.blit(label_nom, (LARGEUR_FENETRE // 2 - 150, 220))
        
        # Champ de nom
        self.champ_nom.dessiner(surface)
        
        # Label pour le rôle
        label_role = police_label.render("Choisissez votre rôle:", True, BLANC)
        surface.blit(label_role, (LARGEUR_FENETRE // 2 - 100, 330))
        
        # Boutons de rôle
        self.bouton_concepteur.dessiner(surface)
        self.bouton_pragmatique.dessiner(surface)
        
        # Descriptions des rôles
        police_desc = pygame.font.Font(None, 20)
        
        desc1 = police_desc.render(self.desc_concepteur, True, GRIS_CLAIR)
        desc1_rect = desc1.get_rect(center=(LARGEUR_FENETRE // 2 - 170, 430))
        surface.blit(desc1, desc1_rect)
        
        desc2 = police_desc.render(self.desc_pragmatique, True, GRIS_CLAIR)
        desc2_rect = desc2.get_rect(center=(LARGEUR_FENETRE // 2 + 170, 430))
        surface.blit(desc2, desc2_rect)
        
        # Boutons
        self.bouton_valider.dessiner(surface)
        self.bouton_retour.dessiner(surface)


class EcranChargement:
    """
    Écran de chargement avec animation.
    """
    
    def __init__(self, message=MESSAGE_CHARGEMENT):
        """
        Initialise l'écran de chargement.
        
        Arguments:
            message (str): Message à afficher
        """
        self.message = message
        self.angle_rotation = 0
        self.progression = 0
    
    def mettre_a_jour(self):
        """
        Met à jour l'animation de chargement.
        """
        self.angle_rotation = (self.angle_rotation + 5) % 360
    
    def dessiner(self, surface):
        """
        Dessine l'écran de chargement.
        
        Arguments:
            surface (pygame.Surface): Surface de destination
        """
        # Fond
        surface.fill(BLEU_ESPACE)
        
        # Animation de chargement (cercle qui tourne)
        centre_x = LARGEUR_FENETRE // 2
        centre_y = HAUTEUR_FENETRE // 2 - 50
        rayon = 30
        
        for i in range(8):
            angle = math.radians(self.angle_rotation + i * 45)
            x = centre_x + int(rayon * math.cos(angle))
            y = centre_y + int(rayon * math.sin(angle))
            
            # Les points s'estompent progressivement
            alpha = 255 - (i * 30)
            taille = 8 - i
            
            couleur = (ORANGE_ACCENT[0], ORANGE_ACCENT[1], ORANGE_ACCENT[2])
            pygame.draw.circle(surface, couleur, (x, y), max(2, taille))
        
        # Message
        police = pygame.font.Font(None, TAILLE_POLICE_MENU)
        texte = police.render(self.message, True, BLANC)
        texte_rect = texte.get_rect(center=(centre_x, centre_y + 80))
        surface.blit(texte, texte_rect)


# =============================================================================
# Fonctions utilitaires pour l'affichage
# =============================================================================

def dessiner_texte_centre(surface, texte, y, taille=TAILLE_POLICE_MENU, couleur=BLANC):
    """
    Dessine un texte centré horizontalement.
    
    Arguments:
        surface: Surface PyGame
        texte (str): Texte à afficher
        y (int): Position verticale
        taille (int): Taille de la police
        couleur (tuple): Couleur RGB
    """
    police = pygame.font.Font(None, taille)
    texte_surface = police.render(texte, True, couleur)
    texte_rect = texte_surface.get_rect(center=(LARGEUR_FENETRE // 2, y))
    surface.blit(texte_surface, texte_rect)


def dessiner_fond_spatial(surface, offset_y=0):
    """
    Dessine un fond spatial avec étoiles.
    
    Arguments:
        surface: Surface PyGame
        offset_y (int): Décalage vertical pour l'effet de défilement
    """
    surface.fill(BLEU_ESPACE)
    
    # Étoiles de différentes tailles
    import random
    random.seed(42)  # Pour avoir toujours les mêmes positions
    
    for _ in range(100):
        x = random.randint(0, LARGEUR_FENETRE)
        y = (random.randint(0, HAUTEUR_FENETRE) + offset_y) % HAUTEUR_FENETRE
        taille = random.choice([1, 1, 1, 2, 2, 3])
        luminosite = random.randint(150, 255)
        couleur = (luminosite, luminosite, luminosite)
        pygame.draw.circle(surface, couleur, (x, y), taille)


# =============================================================================
# Tests
# =============================================================================

if __name__ == "__main__":
    pygame.init()
    
    print("=== Test du module interface ORBITE ZÉRO ===")
    print("Ce module nécessite une fenêtre graphique pour être testé.")
    print("Lancez le jeu principal (main.py) pour voir l'interface.")
    
    pygame.quit()
