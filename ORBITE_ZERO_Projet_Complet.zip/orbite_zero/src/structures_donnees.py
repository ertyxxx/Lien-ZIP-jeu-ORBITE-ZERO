"""
=============================================================================
Structures de données du jeu ORBITE ZÉRO
=============================================================================
Ce module définit toutes les structures de données utilisées dans le jeu.
Il contient les classes pour représenter les joueurs, les parties et 
les données de sauvegarde.

Les structures de données sont organisées en classes Python, ce qui permet
une gestion propre et organisée de toutes les informations du jeu.

Auteurs: Équipe Relentless Five
Date: Janvier 2026
Version: 1.0 - Première soutenance
=============================================================================
"""

import json
import os
from datetime import datetime
from config import *


class Joueur:
    """
    Classe représentant un joueur dans le jeu.
    
    Cette classe stocke toutes les informations relatives à un joueur :
    son identifiant, son nom, son rôle, ses statistiques, etc.
    
    Attributs:
        identifiant (int): Numéro unique du joueur (1 ou 2)
        nom (str): Nom choisi par le joueur
        role (str): "Concepteur" ou "Pragmatique"
        points_vie (int): Points de vie actuels
        position_x (float): Position horizontale sur l'écran
        position_y (float): Position verticale sur l'écran
        est_pret (bool): Indique si le joueur est prêt à jouer
        couleur (tuple): Couleur RGB du joueur
    """
    
    def __init__(self, identifiant, nom="", role=""):
        """
        Initialise un nouveau joueur.
        
        Arguments:
            identifiant (int): 1 pour le joueur 1, 2 pour le joueur 2
            nom (str): Nom du joueur (optionnel)
            role (str): Rôle choisi (optionnel)
        """
        # Identifiant unique du joueur
        self.identifiant = identifiant
        
        # Informations de base
        self.nom = nom
        self.role = role
        
        # État du joueur
        self.points_vie = VIE_MAX_JOUEUR
        self.est_pret = False
        self.est_connecte = False
        
        # Position sur l'écran (centre par défaut)
        self.position_x = LARGEUR_FENETRE // 2
        self.position_y = HAUTEUR_FENETRE // 2
        
        # Vitesse de déplacement
        self.vitesse = VITESSE_JOUEUR
        
        # Couleur selon le joueur
        if identifiant == 1:
            self.couleur = COULEUR_JOUEUR_1
        else:
            self.couleur = COULEUR_JOUEUR_2
        
        # Statistiques de la partie
        self.score = 0
        self.taches_completees = 0
        
        # Horodatage de création
        self.date_creation = datetime.now().isoformat()
    
    def definir_nom(self, nouveau_nom):
        """
        Définit le nom du joueur.
        
        Arguments:
            nouveau_nom (str): Le nouveau nom à attribuer
        
        Retourne:
            bool: True si le nom est valide, False sinon
        """
        # Vérification que le nom n'est pas vide et pas trop long
        if nouveau_nom and len(nouveau_nom) <= 20:
            self.nom = nouveau_nom.strip()
            return True
        return False
    
    def definir_role(self, nouveau_role):
        """
        Définit le rôle du joueur.
        
        Arguments:
            nouveau_role (str): "Concepteur" ou "Pragmatique"
        
        Retourne:
            bool: True si le rôle est valide, False sinon
        """
        roles_valides = ["Concepteur", "Pragmatique"]
        if nouveau_role in roles_valides:
            self.role = nouveau_role
            return True
        return False
    
    def deplacer(self, direction_x, direction_y):
        """
        Déplace le joueur dans la direction indiquée.
        
        Arguments:
            direction_x (int): -1 (gauche), 0 (aucun), 1 (droite)
            direction_y (int): -1 (haut), 0 (aucun), 1 (bas)
        """
        # Calcul de la nouvelle position
        nouvelle_x = self.position_x + (direction_x * self.vitesse)
        nouvelle_y = self.position_y + (direction_y * self.vitesse)
        
        # Vérification des limites de l'écran
        if 0 <= nouvelle_x <= LARGEUR_FENETRE - TAILLE_JOUEUR:
            self.position_x = nouvelle_x
        
        if 0 <= nouvelle_y <= HAUTEUR_FENETRE - TAILLE_JOUEUR:
            self.position_y = nouvelle_y
    
    def subir_degats(self, quantite):
        """
        Réduit les points de vie du joueur.
        
        Arguments:
            quantite (int): Nombre de points de vie à retirer
        
        Retourne:
            bool: True si le joueur est encore en vie, False sinon
        """
        self.points_vie = max(0, self.points_vie - quantite)
        return self.points_vie > 0
    
    def soigner(self, quantite):
        """
        Restaure des points de vie au joueur.
        
        Arguments:
            quantite (int): Nombre de points de vie à ajouter
        """
        self.points_vie = min(VIE_MAX_JOUEUR, self.points_vie + quantite)
    
    def vers_dictionnaire(self):
        """
        Convertit les données du joueur en dictionnaire.
        Utile pour la sauvegarde et la transmission réseau.
        
        Retourne:
            dict: Dictionnaire contenant toutes les données du joueur
        """
        return {
            "identifiant": self.identifiant,
            "nom": self.nom,
            "role": self.role,
            "points_vie": self.points_vie,
            "position_x": self.position_x,
            "position_y": self.position_y,
            "score": self.score,
            "est_pret": self.est_pret,
            "date_creation": self.date_creation
        }
    
    @classmethod
    def depuis_dictionnaire(cls, donnees):
        """
        Crée un joueur à partir d'un dictionnaire.
        Utile pour charger une sauvegarde ou recevoir des données réseau.
        
        Arguments:
            donnees (dict): Dictionnaire contenant les données du joueur
        
        Retourne:
            Joueur: Instance de Joueur avec les données chargées
        """
        joueur = cls(donnees["identifiant"], donnees["nom"], donnees["role"])
        joueur.points_vie = donnees.get("points_vie", VIE_MAX_JOUEUR)
        joueur.position_x = donnees.get("position_x", LARGEUR_FENETRE // 2)
        joueur.position_y = donnees.get("position_y", HAUTEUR_FENETRE // 2)
        joueur.score = donnees.get("score", 0)
        joueur.est_pret = donnees.get("est_pret", False)
        return joueur
    
    def __str__(self):
        """
        Représentation textuelle du joueur pour le débogage.
        """
        return f"Joueur {self.identifiant}: {self.nom} ({self.role}) - PV: {self.points_vie}"


class Partie:
    """
    Classe représentant une partie en cours.
    
    Cette classe gère l'état global d'une partie, incluant les deux joueurs,
    le score de l'équipe, le temps restant, et les objectifs.
    
    Attributs:
        joueur1 (Joueur): Le premier joueur (Le Concepteur)
        joueur2 (Joueur): Le deuxième joueur (Le Pragmatique)
        temps_restant (int): Temps restant en secondes
        score_equipe (int): Score total de l'équipe
        etat (str): État actuel de la partie
    """
    
    def __init__(self):
        """
        Initialise une nouvelle partie.
        """
        # Création des deux joueurs
        self.joueur1 = Joueur(1)
        self.joueur2 = Joueur(2)
        
        # Temps de jeu (10 minutes par défaut)
        self.temps_total = 600  # en secondes
        self.temps_restant = self.temps_total
        
        # Score et progression
        self.score_equipe = 0
        self.canons_repares = 0
        self.canons_total = 5  # Nombre de canons à réparer pour gagner
        
        # État de la partie
        self.etat = ETAT_MENU_PRINCIPAL
        self.est_en_cours = False
        self.est_terminee = False
        self.victoire = False
        
        # Horodatage
        self.date_debut = None
        self.date_fin = None
    
    def demarrer(self):
        """
        Démarre la partie.
        
        Retourne:
            bool: True si la partie peut démarrer, False sinon
        """
        # Vérification que les deux joueurs sont prêts
        if self.joueur1.est_pret and self.joueur2.est_pret:
            self.etat = ETAT_EN_JEU
            self.est_en_cours = True
            self.date_debut = datetime.now().isoformat()
            return True
        return False
    
    def mettre_a_jour_temps(self, delta_temps):
        """
        Met à jour le temps restant.
        
        Arguments:
            delta_temps (float): Temps écoulé depuis la dernière mise à jour
        """
        if self.est_en_cours:
            self.temps_restant -= delta_temps
            if self.temps_restant <= 0:
                self.temps_restant = 0
                self.terminer_partie(victoire=False)
    
    def reparer_canon(self):
        """
        Enregistre la réparation d'un canon.
        
        Retourne:
            bool: True si tous les canons sont réparés, False sinon
        """
        self.canons_repares += 1
        self.score_equipe += 100  # Points bonus par canon
        
        if self.canons_repares >= self.canons_total:
            self.terminer_partie(victoire=True)
            return True
        return False
    
    def terminer_partie(self, victoire):
        """
        Termine la partie.
        
        Arguments:
            victoire (bool): True si les joueurs ont gagné, False sinon
        """
        self.est_en_cours = False
        self.est_terminee = True
        self.victoire = victoire
        self.etat = ETAT_FIN_PARTIE
        self.date_fin = datetime.now().isoformat()
    
    def obtenir_temps_formate(self):
        """
        Retourne le temps restant au format MM:SS.
        
        Retourne:
            str: Temps formaté (ex: "05:30")
        """
        minutes = int(self.temps_restant) // 60
        secondes = int(self.temps_restant) % 60
        return f"{minutes:02d}:{secondes:02d}"
    
    def vers_dictionnaire(self):
        """
        Convertit la partie en dictionnaire pour la sauvegarde.
        """
        return {
            "joueur1": self.joueur1.vers_dictionnaire(),
            "joueur2": self.joueur2.vers_dictionnaire(),
            "temps_restant": self.temps_restant,
            "score_equipe": self.score_equipe,
            "canons_repares": self.canons_repares,
            "etat": self.etat,
            "date_debut": self.date_debut,
            "date_fin": self.date_fin
        }


class GestionnaireDonnees:
    """
    Classe pour gérer la sauvegarde et le chargement des données.
    
    Cette classe fournit des méthodes pour sauvegarder et charger
    les données du jeu (profils joueurs, parties, statistiques).
    
    Attributs:
        dossier_donnees (str): Chemin vers le dossier de données
    """
    
    def __init__(self, dossier_donnees=CHEMIN_DONNEES):
        """
        Initialise le gestionnaire de données.
        
        Arguments:
            dossier_donnees (str): Chemin vers le dossier de sauvegarde
        """
        self.dossier_donnees = dossier_donnees
        
        # Création du dossier s'il n'existe pas
        if not os.path.exists(dossier_donnees):
            os.makedirs(dossier_donnees)
    
    def sauvegarder_partie(self, partie, nom_fichier="sauvegarde.json"):
        """
        Sauvegarde une partie dans un fichier JSON.
        
        Arguments:
            partie (Partie): La partie à sauvegarder
            nom_fichier (str): Nom du fichier de sauvegarde
        
        Retourne:
            bool: True si la sauvegarde a réussi, False sinon
        """
        try:
            chemin = os.path.join(self.dossier_donnees, nom_fichier)
            with open(chemin, 'w', encoding='utf-8') as fichier:
                json.dump(partie.vers_dictionnaire(), fichier, 
                         indent=4, ensure_ascii=False)
            return True
        except Exception as erreur:
            print(f"Erreur lors de la sauvegarde: {erreur}")
            return False
    
    def charger_partie(self, nom_fichier="sauvegarde.json"):
        """
        Charge une partie depuis un fichier JSON.
        
        Arguments:
            nom_fichier (str): Nom du fichier à charger
        
        Retourne:
            Partie ou None: La partie chargée ou None si erreur
        """
        try:
            chemin = os.path.join(self.dossier_donnees, nom_fichier)
            if os.path.exists(chemin):
                with open(chemin, 'r', encoding='utf-8') as fichier:
                    donnees = json.load(fichier)
                
                # Reconstruction de la partie
                partie = Partie()
                partie.joueur1 = Joueur.depuis_dictionnaire(donnees["joueur1"])
                partie.joueur2 = Joueur.depuis_dictionnaire(donnees["joueur2"])
                partie.temps_restant = donnees["temps_restant"]
                partie.score_equipe = donnees["score_equipe"]
                partie.canons_repares = donnees["canons_repares"]
                partie.etat = donnees["etat"]
                
                return partie
        except Exception as erreur:
            print(f"Erreur lors du chargement: {erreur}")
        return None
    
    def sauvegarder_profil(self, joueur, nom_fichier=None):
        """
        Sauvegarde le profil d'un joueur.
        
        Arguments:
            joueur (Joueur): Le joueur à sauvegarder
            nom_fichier (str): Nom du fichier (optionnel)
        """
        if nom_fichier is None:
            nom_fichier = f"profil_joueur{joueur.identifiant}.json"
        
        try:
            chemin = os.path.join(self.dossier_donnees, nom_fichier)
            with open(chemin, 'w', encoding='utf-8') as fichier:
                json.dump(joueur.vers_dictionnaire(), fichier,
                         indent=4, ensure_ascii=False)
            return True
        except Exception as erreur:
            print(f"Erreur lors de la sauvegarde du profil: {erreur}")
            return False


# =============================================================================
# Tests et démonstration
# =============================================================================
if __name__ == "__main__":
    # Test des structures de données
    print("=== Test des structures de données ORBITE ZÉRO ===\n")
    
    # Création d'une partie
    partie = Partie()
    
    # Configuration des joueurs
    partie.joueur1.definir_nom("Ilian")
    partie.joueur1.definir_role("Concepteur")
    partie.joueur1.est_pret = True
    
    partie.joueur2.definir_nom("Louis")
    partie.joueur2.definir_role("Pragmatique")
    partie.joueur2.est_pret = True
    
    # Affichage des informations
    print(partie.joueur1)
    print(partie.joueur2)
    print(f"\nTemps restant: {partie.obtenir_temps_formate()}")
    
    # Test de sauvegarde
    gestionnaire = GestionnaireDonnees()
    if gestionnaire.sauvegarder_partie(partie, "test_sauvegarde.json"):
        print("\nSauvegarde réussie !")
    
    print("\n=== Fin des tests ===")
