"""
=============================================================================
ORBITE ZÉRO - Fichier Principal
=============================================================================
Point d'entrée du jeu ORBITE ZÉRO.

Ce fichier contient la boucle principale du jeu et gère les transitions
entre les différents écrans (menu, création de joueur, jeu, etc.).

Pour lancer le jeu, exécutez ce fichier :
    python main.py

Auteurs: Équipe Relentless Five
    - Ilian Drouin (Chef de projet)
    - Samy El-Alaoui
    - Ahmed Shanan
    - Louis Murail
    - Melvyn Tchatchou

Date: Janvier 2026
Version: 1.0 - Première soutenance

École: EPITA - Classe B1.1
Projet: SAE J3D 2025-2026
=============================================================================
"""

import pygame
import sys
import os

# Ajout du dossier src au chemin Python
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))

# Import des modules du jeu
from config import *
from structures_donnees import Joueur, Partie, GestionnaireDonnees
from audio import GestionnaireAudio, obtenir_gestionnaire_audio
from reseau import ServeurJeu, ClientJeu, TypesMessages, creer_message
from interface import (
    MenuPrincipal, 
    EcranCreationJoueur, 
    EcranChargement,
    dessiner_texte_centre,
    dessiner_fond_spatial
)


class JeuOrbiteZero:
    """
    Classe principale du jeu ORBITE ZÉRO.
    
    Cette classe gère l'initialisation de PyGame et des ressources,
    la boucle principale du jeu, les transitions entre les écrans
    et la gestion des événements.
    """
    
    def __init__(self):
        """
        Initialise le jeu et PyGame.
        """
        # Initialisation de PyGame
        pygame.init()
        pygame.font.init()
        
        # Création de la fenêtre
        self.ecran = pygame.display.set_mode((LARGEUR_FENETRE, HAUTEUR_FENETRE))
        pygame.display.set_caption(TITRE_JEU)
        
        # Horloge pour contrôler le FPS
        self.horloge = pygame.time.Clock()
        
        # État du jeu
        self.en_cours = True
        self.etat = ETAT_MENU_PRINCIPAL
        
        # Gestionnaires
        self.audio = obtenir_gestionnaire_audio()
        self.donnees = GestionnaireDonnees()
        
        # Réseau
        self.serveur = None
        self.client = None
        self.est_hote = False
        
        # Partie en cours
        self.partie = None
        
        # Écrans et menus
        self.menu_principal = MenuPrincipal()
        self.ecran_creation = None
        self.ecran_chargement = EcranChargement()
        
        # Joueur local
        self.joueur_local = None
        self.numero_joueur = 0
        
        # Message d'information
        self.message_info = ""
        self.temps_message = 0
        
        print("[Jeu] ORBITE ZÉRO initialisé")
        print(f"[Jeu] Résolution: {LARGEUR_FENETRE}x{HAUTEUR_FENETRE}")
    
    def afficher_message(self, message, duree=3000):
        """Affiche un message temporaire."""
        self.message_info = message
        self.temps_message = pygame.time.get_ticks() + duree
    
    def gerer_evenements(self):
        """Gère tous les événements PyGame."""
        evenements_clavier = []
        
        for evenement in pygame.event.get():
            if evenement.type == pygame.QUIT:
                self.en_cours = False
            elif evenement.type == pygame.KEYDOWN:
                evenements_clavier.append(evenement)
                if evenement.key == pygame.K_ESCAPE:
                    if self.etat == ETAT_MENU_PRINCIPAL:
                        self.en_cours = False
                    else:
                        self.retour_menu_principal()
        
        return evenements_clavier
    
    def retour_menu_principal(self):
        """Retourne au menu principal."""
        if self.serveur:
            self.serveur.arreter()
            self.serveur = None
        if self.client:
            self.client.deconnecter()
            self.client = None
        
        self.partie = None
        self.joueur_local = None
        self.etat = ETAT_MENU_PRINCIPAL
        self.menu_principal = MenuPrincipal()
        print("[Jeu] Retour au menu principal")
    
    def mettre_a_jour_menu_principal(self, evenements_clavier):
        """Met à jour le menu principal."""
        position_souris = pygame.mouse.get_pos()
        clic_souris = pygame.mouse.get_pressed()[0]
        
        for evenement in evenements_clavier:
            if evenement.key == pygame.K_UP:
                self.menu_principal.naviguer(-1)
                self.audio.jouer_son_menu("selection")
            elif evenement.key == pygame.K_DOWN:
                self.menu_principal.naviguer(1)
                self.audio.jouer_son_menu("selection")
            elif evenement.key == pygame.K_RETURN:
                self.traiter_selection_menu(self.menu_principal.obtenir_selection())
        
        selection = self.menu_principal.mettre_a_jour(position_souris, clic_souris)
        if selection is not None:
            self.audio.jouer_son_menu("validation")
            self.traiter_selection_menu(selection)
    
    def traiter_selection_menu(self, index):
        """Traite la sélection dans le menu principal."""
        if index == 0:  # Nouvelle Partie
            self.demarrer_nouvelle_partie()
        elif index == 1:  # Rejoindre une Partie
            self.rejoindre_partie()
        elif index == 2:  # Options
            self.afficher_message("Options - Fonctionnalité à venir")
        elif index == 3:  # Quitter
            self.en_cours = False
    
    def demarrer_nouvelle_partie(self):
        """Démarre le processus de création d'une nouvelle partie."""
        print("[Jeu] Démarrage d'une nouvelle partie...")
        self.est_hote = True
        self.numero_joueur = 1
        self.ecran_creation = EcranCreationJoueur(1)
        self.etat = ETAT_CREATION_JOUEUR
        self.afficher_message("Configurez votre personnage")
    
    def rejoindre_partie(self):
        """Démarre le processus pour rejoindre une partie."""
        print("[Jeu] Rejoindre une partie...")
        self.est_hote = False
        self.numero_joueur = 2
        self.ecran_creation = EcranCreationJoueur(2)
        self.etat = ETAT_CREATION_JOUEUR
        self.afficher_message("Configurez votre personnage")
    
    def mettre_a_jour_creation_joueur(self, evenements_clavier):
        """Met à jour l'écran de création de joueur."""
        position_souris = pygame.mouse.get_pos()
        clic_souris = pygame.mouse.get_pressed()[0]
        
        for evenement in evenements_clavier:
            self.ecran_creation.mettre_a_jour(position_souris, False, evenement)
        
        action = self.ecran_creation.mettre_a_jour(position_souris, clic_souris)
        
        if action == "retour":
            self.retour_menu_principal()
        elif action == "valider":
            self.valider_creation_joueur()
    
    def valider_creation_joueur(self):
        """Valide la création du joueur."""
        donnees = self.ecran_creation.obtenir_donnees_joueur()
        
        self.joueur_local = Joueur(self.numero_joueur)
        self.joueur_local.definir_nom(donnees["nom"])
        self.joueur_local.definir_role(donnees["role"])
        self.joueur_local.est_pret = True
        
        print(f"[Jeu] Joueur créé: {self.joueur_local}")
        
        if self.est_hote:
            self.demarrer_serveur()
        else:
            self.etat = ETAT_ATTENTE_CONNEXION
            self.ecran_chargement.message = MESSAGE_CONNEXION
            self.connecter_au_serveur("localhost")
    
    def demarrer_serveur(self):
        """Démarre le serveur de jeu."""
        self.serveur = ServeurJeu()
        
        if self.serveur.demarrer():
            ip = self.serveur.obtenir_adresse_ip()
            self.afficher_message(f"Serveur démarré - IP: {ip}", 5000)
            self.etat = ETAT_ATTENTE_CONNEXION
            self.ecran_chargement.message = MESSAGE_ATTENTE_JOUEUR
            self.serveur.callback_connexion = self.on_client_connecte
            self.serveur.callback_message = self.on_message_recu
        else:
            self.afficher_message("Erreur lors du démarrage du serveur")
            self.retour_menu_principal()
    
    def connecter_au_serveur(self, adresse):
        """Connecte le client à un serveur."""
        self.client = ClientJeu()
        
        if self.client.connecter(adresse):
            self.afficher_message("Connecté au serveur!")
            message = creer_message(TypesMessages.JOUEUR_PRET, 
                                   self.joueur_local.vers_dictionnaire())
            self.client.envoyer(message)
            self.client.callback_message = self.on_message_recu
            self.ecran_chargement.message = "En attente du démarrage..."
        else:
            self.afficher_message("Impossible de se connecter au serveur")
    
    def on_client_connecte(self, adresse):
        """Callback quand un client se connecte."""
        print(f"[Jeu] Client connecté: {adresse}")
        self.afficher_message("Joueur 2 connecté!")
        self.partie = Partie()
        self.partie.joueur1 = self.joueur_local
        message = creer_message(TypesMessages.SYNC_PARTIE,
                               self.partie.vers_dictionnaire())
        self.serveur.envoyer(message)
    
    def on_message_recu(self, message):
        """Callback quand un message réseau est reçu."""
        type_msg = message.get("type")
        donnees = message.get("donnees", {})
        
        print(f"[Jeu] Message reçu: {type_msg}")
        
        if type_msg == TypesMessages.JOUEUR_PRET:
            if self.est_hote and self.partie:
                self.partie.joueur2 = Joueur.depuis_dictionnaire(donnees)
                self.partie.joueur2.est_pret = True
                if self.partie.joueur1.est_pret and self.partie.joueur2.est_pret:
                    self.demarrer_jeu()
        elif type_msg == TypesMessages.DEMARRER_PARTIE:
            self.etat = ETAT_EN_JEU
            self.afficher_message("La partie commence!")
    
    def demarrer_jeu(self):
        """Lance le jeu."""
        print("[Jeu] Démarrage du jeu!")
        if self.est_hote:
            message = creer_message(TypesMessages.DEMARRER_PARTIE)
            self.serveur.envoyer(message)
        self.etat = ETAT_EN_JEU
        self.partie.demarrer()
        self.afficher_message("La partie commence!")
    
    def mettre_a_jour_attente(self):
        """Met à jour l'écran d'attente."""
        self.ecran_chargement.mettre_a_jour()
        
        if self.serveur:
            message = self.serveur.obtenir_message()
            if message:
                self.on_message_recu(message)
        if self.client:
            message = self.client.obtenir_message()
            if message:
                self.on_message_recu(message)
    
    def mettre_a_jour_jeu(self, evenements_clavier):
        """Met à jour la logique du jeu principal."""
        if not self.partie:
            return
        
        delta = self.horloge.get_time() / 1000.0
        self.partie.mettre_a_jour_temps(delta)
        
        touches = pygame.key.get_pressed()
        direction_x = 0
        direction_y = 0
        
        if touches[pygame.K_LEFT] or touches[pygame.K_q]:
            direction_x = -1
        if touches[pygame.K_RIGHT] or touches[pygame.K_d]:
            direction_x = 1
        if touches[pygame.K_UP] or touches[pygame.K_z]:
            direction_y = -1
        if touches[pygame.K_DOWN] or touches[pygame.K_s]:
            direction_y = 1
        
        if self.joueur_local:
            self.joueur_local.deplacer(direction_x, direction_y)
    
    def dessiner(self):
        """Dessine l'écran actuel."""
        if self.etat == ETAT_MENU_PRINCIPAL:
            self.menu_principal.dessiner_fond(self.ecran)
            self.menu_principal.dessiner(self.ecran)
        elif self.etat == ETAT_CREATION_JOUEUR:
            self.ecran_creation.dessiner(self.ecran)
        elif self.etat == ETAT_ATTENTE_CONNEXION:
            self.ecran_chargement.dessiner(self.ecran)
        elif self.etat == ETAT_EN_JEU:
            self.dessiner_jeu()
        
        if self.message_info and pygame.time.get_ticks() < self.temps_message:
            self.dessiner_message_info()
        
        pygame.display.flip()
    
    def dessiner_jeu(self):
        """Dessine l'écran de jeu principal."""
        dessiner_fond_spatial(self.ecran)
        
        if self.joueur_local:
            pygame.draw.rect(
                self.ecran, 
                self.joueur_local.couleur,
                (self.joueur_local.position_x, 
                 self.joueur_local.position_y,
                 TAILLE_JOUEUR, TAILLE_JOUEUR),
                border_radius=8
            )
            
            police = pygame.font.Font(None, 20)
            nom_surface = police.render(self.joueur_local.nom, True, BLANC)
            nom_rect = nom_surface.get_rect(
                centerx=self.joueur_local.position_x + TAILLE_JOUEUR // 2,
                top=self.joueur_local.position_y + TAILLE_JOUEUR + 5
            )
            self.ecran.blit(nom_surface, nom_rect)
        
        if self.partie:
            temps_texte = f"Temps: {self.partie.obtenir_temps_formate()}"
            dessiner_texte_centre(self.ecran, temps_texte, 30, TAILLE_POLICE_MENU, ORANGE_ACCENT)
            
            police = pygame.font.Font(None, TAILLE_POLICE_PETIT)
            score_texte = f"Score: {self.partie.score_equipe}"
            texte_surface = police.render(score_texte, True, BLANC)
            self.ecran.blit(texte_surface, (20, 20))
            
            canons_texte = f"Canons: {self.partie.canons_repares}/{self.partie.canons_total}"
            texte_surface = police.render(canons_texte, True, VERT_SYSTEME)
            self.ecran.blit(texte_surface, (20, 50))
    
    def dessiner_message_info(self):
        """Dessine le message d'information."""
        police = pygame.font.Font(None, TAILLE_POLICE_PETIT)
        texte_surface = police.render(self.message_info, True, JAUNE_AVERTISSEMENT)
        texte_rect = texte_surface.get_rect(
            center=(LARGEUR_FENETRE // 2, HAUTEUR_FENETRE - 40)
        )
        
        fond_rect = texte_rect.inflate(20, 10)
        fond_surface = pygame.Surface((fond_rect.width, fond_rect.height))
        fond_surface.fill(NOIR)
        fond_surface.set_alpha(180)
        self.ecran.blit(fond_surface, fond_rect)
        self.ecran.blit(texte_surface, texte_rect)
    
    def boucle_principale(self):
        """Boucle principale du jeu."""
        print("[Jeu] Démarrage de la boucle principale")
        
        while self.en_cours:
            evenements_clavier = self.gerer_evenements()
            
            if self.etat == ETAT_MENU_PRINCIPAL:
                self.mettre_a_jour_menu_principal(evenements_clavier)
            elif self.etat == ETAT_CREATION_JOUEUR:
                self.mettre_a_jour_creation_joueur(evenements_clavier)
            elif self.etat == ETAT_ATTENTE_CONNEXION:
                self.mettre_a_jour_attente()
            elif self.etat == ETAT_EN_JEU:
                self.mettre_a_jour_jeu(evenements_clavier)
            
            self.dessiner()
            self.horloge.tick(FPS)
        
        print("[Jeu] Fin de la boucle principale")
    
    def quitter(self):
        """Nettoie les ressources et quitte le jeu."""
        print("[Jeu] Fermeture du jeu...")
        
        if self.serveur:
            self.serveur.arreter()
        if self.client:
            self.client.deconnecter()
        
        self.audio.nettoyer()
        pygame.quit()
        print("[Jeu] Au revoir !")


def main():
    """Fonction principale - Point d'entrée du jeu."""
    print("=" * 60)
    print("       ORBITE ZÉRO - Sauvez la Terre !")
    print("       Équipe Relentless Five - EPITA B1.1")
    print("=" * 60)
    
    jeu = JeuOrbiteZero()
    
    try:
        jeu.boucle_principale()
    except KeyboardInterrupt:
        print("\n[Jeu] Interruption par l'utilisateur")
    except Exception as erreur:
        print(f"\n[Jeu] Erreur: {erreur}")
        import traceback
        traceback.print_exc()
    finally:
        jeu.quitter()


if __name__ == "__main__":
    main()
