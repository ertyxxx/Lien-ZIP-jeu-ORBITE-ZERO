"""
=============================================================================
Module réseau pour le multijoueur - ORBITE ZÉRO
=============================================================================
Ce module gère toute la communication réseau pour le mode multijoueur LAN.

Le jeu utilise une architecture client-serveur simple :
- Un joueur crée une partie (devient le serveur)
- L'autre joueur rejoint la partie (devient le client)

La communication se fait via des sockets TCP pour garantir
la fiabilité des messages.

Auteurs: Équipe Relentless Five
Date: Janvier 2026
Version: 1.0 - Première soutenance
=============================================================================
"""

import socket
import threading
import json
import time
from config import *


class ServeurJeu:
    """
    Classe serveur pour héberger une partie multijoueur.
    
    Le serveur :
    - Écoute les connexions entrantes
    - Accepte un client (joueur 2)
    - Synchronise les données de jeu entre les joueurs
    
    Attributs:
        socket_serveur: Socket d'écoute pour les connexions
        socket_client: Socket du client connecté
        adresse_client: Adresse IP du client
        est_connecte (bool): True si un client est connecté
    """
    
    def __init__(self, port=PORT_SERVEUR):
        """
        Initialise le serveur.
        
        Arguments:
            port (int): Port d'écoute du serveur
        """
        self.port = port
        self.socket_serveur = None
        self.socket_client = None
        self.adresse_client = None
        
        # États
        self.est_actif = False
        self.est_connecte = False
        
        # Thread d'écoute
        self.thread_ecoute = None
        
        # File de messages reçus
        self.messages_recus = []
        
        # Callback pour les événements
        self.callback_connexion = None
        self.callback_message = None
        self.callback_deconnexion = None
        
        print("[Serveur] Instance créée")
    
    def obtenir_adresse_ip(self):
        """
        Obtient l'adresse IP locale de la machine.
        
        Retourne:
            str: Adresse IP locale
        """
        try:
            # Crée une connexion fictive pour obtenir l'IP locale
            s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
            s.connect(("8.8.8.8", 80))
            ip = s.getsockname()[0]
            s.close()
            return ip
        except:
            return "127.0.0.1"
    
    def demarrer(self):
        """
        Démarre le serveur et commence à écouter les connexions.
        
        Retourne:
            bool: True si le serveur a démarré avec succès
        """
        try:
            # Création du socket serveur
            self.socket_serveur = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            
            # Permet de réutiliser l'adresse immédiatement
            self.socket_serveur.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
            
            # Liaison au port
            self.socket_serveur.bind(('', self.port))
            
            # Écoute avec 1 connexion en attente max
            self.socket_serveur.listen(1)
            
            self.est_actif = True
            
            # Démarrage du thread d'écoute
            self.thread_ecoute = threading.Thread(target=self._boucle_ecoute)
            self.thread_ecoute.daemon = True
            self.thread_ecoute.start()
            
            ip = self.obtenir_adresse_ip()
            print(f"[Serveur] Démarré sur {ip}:{self.port}")
            return True
            
        except socket.error as erreur:
            print(f"[Serveur] Erreur de démarrage: {erreur}")
            return False
    
    def _boucle_ecoute(self):
        """
        Boucle d'écoute pour les connexions entrantes.
        Exécutée dans un thread séparé.
        """
        print("[Serveur] En attente d'une connexion...")
        
        try:
            # Timeout pour pouvoir arrêter proprement
            self.socket_serveur.settimeout(1.0)
            
            while self.est_actif:
                try:
                    # Attente d'une connexion
                    client_socket, adresse = self.socket_serveur.accept()
                    
                    self.socket_client = client_socket
                    self.adresse_client = adresse
                    self.est_connecte = True
                    
                    print(f"[Serveur] Client connecté: {adresse}")
                    
                    # Notification de connexion
                    if self.callback_connexion:
                        self.callback_connexion(adresse)
                    
                    # Démarrage de la réception des messages
                    self._boucle_reception()
                    
                except socket.timeout:
                    continue
                    
        except Exception as erreur:
            if self.est_actif:
                print(f"[Serveur] Erreur d'écoute: {erreur}")
    
    def _boucle_reception(self):
        """
        Boucle de réception des messages du client.
        """
        self.socket_client.settimeout(1.0)
        
        while self.est_actif and self.est_connecte:
            try:
                # Réception des données (max 4096 octets)
                donnees = self.socket_client.recv(4096)
                
                if donnees:
                    # Décodage du message JSON
                    message = json.loads(donnees.decode('utf-8'))
                    self.messages_recus.append(message)
                    
                    # Notification
                    if self.callback_message:
                        self.callback_message(message)
                else:
                    # Connexion fermée par le client
                    self._gerer_deconnexion()
                    
            except socket.timeout:
                continue
            except json.JSONDecodeError:
                print("[Serveur] Message invalide reçu")
            except Exception as erreur:
                if self.est_connecte:
                    print(f"[Serveur] Erreur de réception: {erreur}")
                    self._gerer_deconnexion()
    
    def _gerer_deconnexion(self):
        """
        Gère la déconnexion du client.
        """
        self.est_connecte = False
        
        if self.socket_client:
            self.socket_client.close()
            self.socket_client = None
        
        print("[Serveur] Client déconnecté")
        
        if self.callback_deconnexion:
            self.callback_deconnexion()
    
    def envoyer(self, message):
        """
        Envoie un message au client connecté.
        
        Arguments:
            message (dict): Dictionnaire à envoyer
        
        Retourne:
            bool: True si l'envoi a réussi
        """
        if not self.est_connecte or not self.socket_client:
            return False
        
        try:
            # Encodage en JSON
            donnees = json.dumps(message).encode('utf-8')
            self.socket_client.sendall(donnees)
            return True
        except Exception as erreur:
            print(f"[Serveur] Erreur d'envoi: {erreur}")
            return False
    
    def obtenir_message(self):
        """
        Récupère le premier message de la file.
        
        Retourne:
            dict ou None: Le message ou None si la file est vide
        """
        if self.messages_recus:
            return self.messages_recus.pop(0)
        return None
    
    def arreter(self):
        """
        Arrête le serveur proprement.
        """
        self.est_actif = False
        self.est_connecte = False
        
        if self.socket_client:
            self.socket_client.close()
        
        if self.socket_serveur:
            self.socket_serveur.close()
        
        print("[Serveur] Arrêté")


class ClientJeu:
    """
    Classe client pour rejoindre une partie multijoueur.
    
    Le client :
    - Se connecte à un serveur existant
    - Envoie et reçoit des données de jeu
    
    Attributs:
        socket: Socket de connexion
        adresse_serveur (str): Adresse IP du serveur
        est_connecte (bool): True si connecté au serveur
    """
    
    def __init__(self):
        """
        Initialise le client.
        """
        self.socket = None
        self.adresse_serveur = None
        self.port_serveur = None
        
        # États
        self.est_connecte = False
        
        # Thread de réception
        self.thread_reception = None
        
        # File de messages
        self.messages_recus = []
        
        # Callbacks
        self.callback_connexion = None
        self.callback_message = None
        self.callback_deconnexion = None
        
        print("[Client] Instance créée")
    
    def connecter(self, adresse, port=PORT_SERVEUR, timeout=TIMEOUT_CONNEXION):
        """
        Connecte le client à un serveur.
        
        Arguments:
            adresse (str): Adresse IP du serveur
            port (int): Port du serveur
            timeout (int): Délai d'attente maximum
        
        Retourne:
            bool: True si la connexion a réussi
        """
        try:
            self.adresse_serveur = adresse
            self.port_serveur = port
            
            # Création du socket
            self.socket = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
            self.socket.settimeout(timeout)
            
            print(f"[Client] Connexion à {adresse}:{port}...")
            
            # Tentative de connexion
            self.socket.connect((adresse, port))
            
            self.est_connecte = True
            print(f"[Client] Connecté au serveur")
            
            # Démarrage du thread de réception
            self.thread_reception = threading.Thread(target=self._boucle_reception)
            self.thread_reception.daemon = True
            self.thread_reception.start()
            
            if self.callback_connexion:
                self.callback_connexion()
            
            return True
            
        except socket.timeout:
            print(f"[Client] Timeout de connexion")
            return False
        except socket.error as erreur:
            print(f"[Client] Erreur de connexion: {erreur}")
            return False
    
    def _boucle_reception(self):
        """
        Boucle de réception des messages du serveur.
        """
        self.socket.settimeout(1.0)
        
        while self.est_connecte:
            try:
                donnees = self.socket.recv(4096)
                
                if donnees:
                    message = json.loads(donnees.decode('utf-8'))
                    self.messages_recus.append(message)
                    
                    if self.callback_message:
                        self.callback_message(message)
                else:
                    self._gerer_deconnexion()
                    
            except socket.timeout:
                continue
            except json.JSONDecodeError:
                print("[Client] Message invalide reçu")
            except Exception as erreur:
                if self.est_connecte:
                    print(f"[Client] Erreur de réception: {erreur}")
                    self._gerer_deconnexion()
    
    def _gerer_deconnexion(self):
        """
        Gère la perte de connexion.
        """
        self.est_connecte = False
        
        if self.socket:
            self.socket.close()
            self.socket = None
        
        print("[Client] Déconnecté du serveur")
        
        if self.callback_deconnexion:
            self.callback_deconnexion()
    
    def envoyer(self, message):
        """
        Envoie un message au serveur.
        
        Arguments:
            message (dict): Dictionnaire à envoyer
        
        Retourne:
            bool: True si l'envoi a réussi
        """
        if not self.est_connecte or not self.socket:
            return False
        
        try:
            donnees = json.dumps(message).encode('utf-8')
            self.socket.sendall(donnees)
            return True
        except Exception as erreur:
            print(f"[Client] Erreur d'envoi: {erreur}")
            return False
    
    def obtenir_message(self):
        """
        Récupère le premier message de la file.
        """
        if self.messages_recus:
            return self.messages_recus.pop(0)
        return None
    
    def deconnecter(self):
        """
        Ferme la connexion avec le serveur.
        """
        self.est_connecte = False
        
        if self.socket:
            self.socket.close()
            self.socket = None
        
        print("[Client] Déconnexion effectuée")


# =============================================================================
# Types de messages pour la communication
# =============================================================================

class TypesMessages:
    """
    Classe définissant les types de messages réseau.
    
    Ces constantes permettent d'identifier le type de chaque message
    envoyé entre le serveur et le client.
    """
    # Messages de connexion
    CONNEXION = "connexion"
    DECONNEXION = "deconnexion"
    PING = "ping"
    PONG = "pong"
    
    # Messages de jeu
    JOUEUR_PRET = "joueur_pret"
    DEMARRER_PARTIE = "demarrer_partie"
    MISE_A_JOUR_POSITION = "position"
    MISE_A_JOUR_ETAT = "etat"
    ACTION_JOUEUR = "action"
    
    # Messages de synchronisation
    SYNC_PARTIE = "sync_partie"
    SYNC_JOUEUR = "sync_joueur"


def creer_message(type_message, donnees=None):
    """
    Crée un message formaté pour l'envoi réseau.
    
    Arguments:
        type_message (str): Type du message (utiliser TypesMessages)
        donnees (dict): Données à inclure dans le message
    
    Retourne:
        dict: Message formaté
    """
    message = {
        "type": type_message,
        "timestamp": time.time()
    }
    
    if donnees:
        message["donnees"] = donnees
    
    return message


# =============================================================================
# Tests et démonstration
# =============================================================================
if __name__ == "__main__":
    print("=== Test du module réseau ORBITE ZÉRO ===\n")
    
    # Test de création du serveur
    print("--- Test du serveur ---")
    serveur = ServeurJeu()
    print(f"Adresse IP locale: {serveur.obtenir_adresse_ip()}")
    
    # Test de création du client
    print("\n--- Test du client ---")
    client = ClientJeu()
    
    # Test de création de message
    print("\n--- Test des messages ---")
    msg = creer_message(TypesMessages.JOUEUR_PRET, {"nom": "Test", "role": "Concepteur"})
    print(f"Message créé: {msg}")
    
    print("\n=== Fin des tests réseau ===")
    print("\nNote: Pour tester la connexion réelle, lancez")
    print("le serveur sur une machine et le client sur une autre.")
