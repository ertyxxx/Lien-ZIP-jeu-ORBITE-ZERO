"""
=============================================================================
Configuration du jeu ORBITE ZÉRO
=============================================================================
Ce fichier contient toutes les constantes et paramètres de configuration
du jeu. Modifier ces valeurs permet de personnaliser l'expérience de jeu.

Auteurs: Équipe Relentless Five
    - Ilian Drouin (Chef de projet)
    - Samy El-Alaoui
    - Ahmed Shanan
    - Louis Murail
    - Melvyn Tchatchou

Date: Janvier 2026
Version: 1.0 - Première soutenance
=============================================================================
"""

# =============================================================================
# CONFIGURATION DE LA FENÊTRE DE JEU
# =============================================================================
# Dimensions de la fenêtre en pixels
LARGEUR_FENETRE = 1280
HAUTEUR_FENETRE = 720

# Titre qui apparaît dans la barre de la fenêtre
TITRE_JEU = "ORBITE ZÉRO - Sauvez la Terre !"

# Nombre d'images par seconde (fluidité du jeu)
FPS = 60

# =============================================================================
# COULEURS DU JEU (format RGB: Rouge, Vert, Bleu)
# =============================================================================
# Couleurs de base
NOIR = (0, 0, 0)
BLANC = (255, 255, 255)
GRIS_FONCE = (30, 30, 40)
GRIS = (100, 100, 100)
GRIS_CLAIR = (200, 200, 200)

# Couleurs du thème spatial
BLEU_ESPACE = (10, 15, 35)
BLEU_NUIT = (20, 25, 50)
ORANGE_ACCENT = (255, 140, 50)
ORANGE_CLAIR = (255, 180, 100)
VERT_SYSTEME = (50, 255, 100)
ROUGE_ALERTE = (255, 50, 50)
JAUNE_AVERTISSEMENT = (255, 220, 50)

# Couleurs pour les joueurs
COULEUR_JOUEUR_1 = (100, 150, 255)  # Bleu - Le Concepteur
COULEUR_JOUEUR_2 = (255, 150, 100)  # Orange - Le Pragmatique

# =============================================================================
# CONFIGURATION DES JOUEURS
# =============================================================================
# Taille des personnages en pixels
TAILLE_JOUEUR = 48

# Vitesse de déplacement des joueurs (pixels par frame)
VITESSE_JOUEUR = 5

# Points de vie maximum
VIE_MAX_JOUEUR = 100

# =============================================================================
# CONFIGURATION RÉSEAU (MULTIJOUEUR)
# =============================================================================
# Port par défaut pour la connexion LAN
PORT_SERVEUR = 5555

# Adresse par défaut du serveur (localhost pour tests locaux)
ADRESSE_SERVEUR = "localhost"

# Délai maximum d'attente pour la connexion (en secondes)
TIMEOUT_CONNEXION = 10

# =============================================================================
# CONFIGURATION DES MENUS
# =============================================================================
# Tailles des polices
TAILLE_POLICE_TITRE = 72
TAILLE_POLICE_SOUS_TITRE = 36
TAILLE_POLICE_MENU = 32
TAILLE_POLICE_PETIT = 24

# Espacement entre les éléments du menu
ESPACEMENT_MENU = 60

# =============================================================================
# CHEMINS DES RESSOURCES
# =============================================================================
# Ces chemins sont relatifs au dossier du jeu
CHEMIN_IMAGES = "assets/images/"
CHEMIN_SONS = "assets/sounds/"
CHEMIN_POLICES = "assets/fonts/"
CHEMIN_DONNEES = "data/"

# =============================================================================
# MESSAGES DU JEU
# =============================================================================
MESSAGE_BIENVENUE = "Bienvenue dans ORBITE ZÉRO"
MESSAGE_INSTRUCTIONS = "Appuyez sur ENTRÉE pour commencer"
MESSAGE_CHARGEMENT = "Chargement en cours..."
MESSAGE_CONNEXION = "Connexion au serveur..."
MESSAGE_ATTENTE_JOUEUR = "En attente d'un autre joueur..."

# =============================================================================
# ÉTATS DU JEU
# =============================================================================
# Ces constantes représentent les différents états possibles du jeu
ETAT_MENU_PRINCIPAL = "menu_principal"
ETAT_CREATION_JOUEUR = "creation_joueur"
ETAT_ATTENTE_CONNEXION = "attente_connexion"
ETAT_EN_JEU = "en_jeu"
ETAT_PAUSE = "pause"
ETAT_FIN_PARTIE = "fin_partie"

# =============================================================================
# CONFIGURATION DES EFFETS SONORES
# =============================================================================
# Volume par défaut (de 0.0 à 1.0)
VOLUME_MUSIQUE = 0.5
VOLUME_EFFETS = 0.7

# Noms des fichiers audio (à créer ultérieurement)
SON_MENU_SELECTION = "menu_select.wav"
SON_MENU_VALIDATION = "menu_valid.wav"
SON_DEPLACEMENT = "footstep.wav"
SON_ALERTE = "alert.wav"
SON_SUCCES = "success.wav"
