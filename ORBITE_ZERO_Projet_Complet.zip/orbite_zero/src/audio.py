"""
=============================================================================
Module de gestion des effets sonores - ORBITE ZÉRO
=============================================================================
Ce module gère tous les aspects audio du jeu : musique d'ambiance,
effets sonores et paramètres de volume.

PyGame utilise le module mixer pour la gestion audio. Ce module simplifie
l'utilisation de mixer en fournissant une interface facile à utiliser.

Auteurs: Équipe Relentless Five
Date: Janvier 2026
Version: 1.0 - Première soutenance
=============================================================================
"""

import pygame
import os
from config import *


class GestionnaireAudio:
    """
    Classe pour gérer tous les sons et la musique du jeu.
    
    Cette classe centralise la gestion audio pour :
    - Charger les fichiers audio
    - Jouer les effets sonores
    - Contrôler la musique de fond
    - Gérer les volumes
    
    Attributs:
        sons (dict): Dictionnaire des effets sonores chargés
        musique_en_cours (str): Nom du fichier musique actuellement joué
        volume_musique (float): Volume de la musique (0.0 à 1.0)
        volume_effets (float): Volume des effets sonores (0.0 à 1.0)
    """
    
    def __init__(self):
        """
        Initialise le gestionnaire audio et le mixer de PyGame.
        """
        # Initialisation du mixer audio de PyGame
        # Les paramètres optimisent la qualité et la latence
        pygame.mixer.pre_init(44100, -16, 2, 512)
        pygame.mixer.init()
        
        # Dictionnaire pour stocker les sons chargés
        self.sons = {}
        
        # État de la musique
        self.musique_en_cours = None
        self.musique_en_pause = False
        
        # Volumes par défaut
        self.volume_musique = VOLUME_MUSIQUE
        self.volume_effets = VOLUME_EFFETS
        
        # Audio activé/désactivé
        self.audio_active = True
        
        # Liste des sons à précharger
        self.liste_sons = [
            "menu_select",      # Sélection dans le menu
            "menu_valid",       # Validation dans le menu
            "deplacement",      # Bruit de pas
            "alerte",           # Son d'alerte
            "succes",           # Réussite d'une action
            "erreur",           # Échec d'une action
            "reparation",       # Son de réparation
            "degats",           # Dégâts subis
            "connexion",        # Connexion établie
        ]
        
        print("[Audio] Gestionnaire audio initialisé")
    
    def charger_son(self, nom, chemin_fichier):
        """
        Charge un effet sonore depuis un fichier.
        
        Arguments:
            nom (str): Identifiant du son (pour l'utiliser plus tard)
            chemin_fichier (str): Chemin vers le fichier audio
        
        Retourne:
            bool: True si le chargement a réussi, False sinon
        """
        try:
            chemin_complet = os.path.join(CHEMIN_SONS, chemin_fichier)
            
            # Vérification que le fichier existe
            if os.path.exists(chemin_complet):
                son = pygame.mixer.Sound(chemin_complet)
                son.set_volume(self.volume_effets)
                self.sons[nom] = son
                print(f"[Audio] Son '{nom}' chargé avec succès")
                return True
            else:
                print(f"[Audio] Fichier non trouvé: {chemin_complet}")
                return False
                
        except pygame.error as erreur:
            print(f"[Audio] Erreur lors du chargement de '{nom}': {erreur}")
            return False
    
    def charger_tous_les_sons(self):
        """
        Charge tous les sons prédéfinis du jeu.
        
        Cette méthode tente de charger tous les sons de la liste.
        Les sons manquants seront ignorés sans bloquer le jeu.
        """
        print("[Audio] Chargement des effets sonores...")
        
        for nom_son in self.liste_sons:
            # Essaie plusieurs extensions courantes
            for extension in ['.wav', '.ogg', '.mp3']:
                fichier = f"{nom_son}{extension}"
                if self.charger_son(nom_son, fichier):
                    break
        
        print(f"[Audio] {len(self.sons)} sons chargés sur {len(self.liste_sons)}")
    
    def jouer_son(self, nom):
        """
        Joue un effet sonore.
        
        Arguments:
            nom (str): Identifiant du son à jouer
        
        Retourne:
            bool: True si le son a été joué, False sinon
        """
        if not self.audio_active:
            return False
        
        if nom in self.sons:
            self.sons[nom].play()
            return True
        else:
            # Le son n'est pas chargé, mais on ne bloque pas le jeu
            return False
    
    def arreter_son(self, nom):
        """
        Arrête un effet sonore en cours.
        
        Arguments:
            nom (str): Identifiant du son à arrêter
        """
        if nom in self.sons:
            self.sons[nom].stop()
    
    def jouer_musique(self, chemin_fichier, boucle=True):
        """
        Joue une musique de fond.
        
        Arguments:
            chemin_fichier (str): Chemin vers le fichier musique
            boucle (bool): Si True, la musique se répète indéfiniment
        """
        if not self.audio_active:
            return
        
        try:
            chemin_complet = os.path.join(CHEMIN_SONS, chemin_fichier)
            
            if os.path.exists(chemin_complet):
                pygame.mixer.music.load(chemin_complet)
                pygame.mixer.music.set_volume(self.volume_musique)
                
                # -1 signifie boucle infinie
                repetitions = -1 if boucle else 0
                pygame.mixer.music.play(repetitions)
                
                self.musique_en_cours = chemin_fichier
                self.musique_en_pause = False
                print(f"[Audio] Musique '{chemin_fichier}' lancée")
            else:
                print(f"[Audio] Fichier musique non trouvé: {chemin_complet}")
                
        except pygame.error as erreur:
            print(f"[Audio] Erreur musique: {erreur}")
    
    def arreter_musique(self, fondu=1000):
        """
        Arrête la musique en cours avec un effet de fondu.
        
        Arguments:
            fondu (int): Durée du fondu en millisecondes
        """
        if pygame.mixer.music.get_busy():
            pygame.mixer.music.fadeout(fondu)
        self.musique_en_cours = None
    
    def pause_musique(self):
        """
        Met la musique en pause.
        """
        pygame.mixer.music.pause()
        self.musique_en_pause = True
    
    def reprendre_musique(self):
        """
        Reprend la musique après une pause.
        """
        pygame.mixer.music.unpause()
        self.musique_en_pause = False
    
    def definir_volume_musique(self, volume):
        """
        Modifie le volume de la musique.
        
        Arguments:
            volume (float): Volume entre 0.0 (muet) et 1.0 (maximum)
        """
        self.volume_musique = max(0.0, min(1.0, volume))
        pygame.mixer.music.set_volume(self.volume_musique)
    
    def definir_volume_effets(self, volume):
        """
        Modifie le volume des effets sonores.
        
        Arguments:
            volume (float): Volume entre 0.0 (muet) et 1.0 (maximum)
        """
        self.volume_effets = max(0.0, min(1.0, volume))
        
        # Mise à jour du volume de tous les sons chargés
        for son in self.sons.values():
            son.set_volume(self.volume_effets)
    
    def basculer_audio(self):
        """
        Active ou désactive tout l'audio.
        
        Retourne:
            bool: Nouvel état de l'audio (True = activé)
        """
        self.audio_active = not self.audio_active
        
        if not self.audio_active:
            self.arreter_musique(fondu=0)
            pygame.mixer.stop()
        
        return self.audio_active
    
    def jouer_son_menu(self, type_son):
        """
        Joue un son de menu spécifique.
        Méthode utilitaire pour simplifier l'utilisation dans les menus.
        
        Arguments:
            type_son (str): "selection", "validation", ou "erreur"
        """
        correspondance = {
            "selection": "menu_select",
            "validation": "menu_valid",
            "erreur": "erreur"
        }
        
        nom_son = correspondance.get(type_son, type_son)
        self.jouer_son(nom_son)
    
    def jouer_son_jeu(self, type_son):
        """
        Joue un son de gameplay.
        
        Arguments:
            type_son (str): Type de son à jouer
        """
        self.jouer_son(type_son)
    
    def nettoyer(self):
        """
        Libère les ressources audio.
        À appeler avant de quitter le jeu.
        """
        self.arreter_musique(fondu=0)
        pygame.mixer.stop()
        self.sons.clear()
        print("[Audio] Ressources audio libérées")


# =============================================================================
# Classe utilitaire pour les sons de déplacement
# =============================================================================

class SonDeplacement:
    """
    Classe pour gérer les sons de déplacement des joueurs.
    
    Cette classe évite de jouer le son de pas trop fréquemment
    en ajoutant un délai entre chaque son.
    """
    
    def __init__(self, gestionnaire_audio, delai_entre_sons=250):
        """
        Initialise le gestionnaire de son de déplacement.
        
        Arguments:
            gestionnaire_audio (GestionnaireAudio): Instance du gestionnaire
            delai_entre_sons (int): Délai minimum entre les sons (ms)
        """
        self.gestionnaire = gestionnaire_audio
        self.delai = delai_entre_sons
        self.dernier_son = 0
    
    def jouer(self):
        """
        Joue le son de déplacement si le délai est écoulé.
        """
        temps_actuel = pygame.time.get_ticks()
        
        if temps_actuel - self.dernier_son >= self.delai:
            self.gestionnaire.jouer_son("deplacement")
            self.dernier_son = temps_actuel


# =============================================================================
# Instance globale du gestionnaire audio (singleton)
# =============================================================================

# Cette instance sera utilisée dans tout le jeu
gestionnaire_audio_global = None


def obtenir_gestionnaire_audio():
    """
    Retourne l'instance globale du gestionnaire audio.
    Crée l'instance si elle n'existe pas encore.
    
    Retourne:
        GestionnaireAudio: Instance du gestionnaire audio
    """
    global gestionnaire_audio_global
    
    if gestionnaire_audio_global is None:
        gestionnaire_audio_global = GestionnaireAudio()
    
    return gestionnaire_audio_global


# =============================================================================
# Tests et démonstration
# =============================================================================
if __name__ == "__main__":
    # Initialisation de PyGame pour les tests
    pygame.init()
    
    print("=== Test du module audio ORBITE ZÉRO ===\n")
    
    # Création du gestionnaire
    audio = GestionnaireAudio()
    
    # Test de chargement
    print("\n--- Test de chargement des sons ---")
    audio.charger_tous_les_sons()
    
    # Test des volumes
    print("\n--- Test des volumes ---")
    print(f"Volume musique: {audio.volume_musique}")
    print(f"Volume effets: {audio.volume_effets}")
    
    audio.definir_volume_musique(0.3)
    print(f"Nouveau volume musique: {audio.volume_musique}")
    
    # Test du basculement audio
    print("\n--- Test activation/désactivation ---")
    print(f"Audio actif: {audio.audio_active}")
    audio.basculer_audio()
    print(f"Audio actif: {audio.audio_active}")
    
    # Nettoyage
    audio.nettoyer()
    pygame.quit()
    
    print("\n=== Fin des tests audio ===")
