# ORBITE ZÉRO

## 🚀 Jeu coopératif spatial - Projet EPITA B1.1

**Équipe Relentless Five**
- Ilian Drouin (Chef de projet)
- Samy El-Alaoui
- Ahmed Shanan
- Louis Murail
- Melvyn Tchatchou

---

## 📖 Synopsis

L'an 3000. Depuis plus d'un siècle, la Terre est protégée par le Système AGERIS : un réseau de canons anti-astéroïdes orbitaux automatisés. Mais aujourd'hui, un astéroïde massif se dirige vers notre planète et le système ne répond plus.

Deux scientifiques aux visions opposées doivent coopérer pour réparer les canons et sauver l'humanité.

---

## 🎮 Installation

### Prérequis
- Python 3.10 ou supérieur
- PyGame 2.5 ou supérieur

### Installation des dépendances

```bash
pip install -r requirements.txt
```

### Lancement du jeu

```bash
python src/main.py
```

---

## 📁 Structure du projet

```
orbite_zero/
├── src/                        # Code source Python
│   ├── main.py                 # Point d'entrée du jeu
│   ├── config.py               # Configuration et constantes
│   ├── structures_donnees.py   # Classes Joueur et Partie
│   ├── audio.py                # Gestion audio
│   ├── reseau.py               # Multijoueur LAN
│   └── interface.py            # Interface graphique
├── assets/                     # Ressources du jeu
│   ├── sounds/                 # Fichiers audio
│   ├── images/                 # Images et sprites
│   └── fonts/                  # Polices
├── docs/                       # Documentation
│   ├── MODE_OPERATOIRE_GIT.md
│   └── MODE_OPERATOIRE_INSTALLATION.md
├── data/                       # Sauvegardes
└── requirements.txt            # Dépendances Python
```

---

## 🎯 Fonctionnalités (Soutenance 1)

- ✅ Menu principal avec navigation clavier/souris
- ✅ Écran de création de joueur (nom + rôle)
- ✅ Architecture réseau client-serveur TCP
- ✅ Structures de données avec sérialisation JSON
- ✅ Système audio avec gestion des volumes

---

## 🔜 Prochaines étapes

- Gameplay complet (déplacements, interactions)
- Synchronisation réseau temps réel
- Intelligence artificielle des ennemis
- Assets graphiques et sonores
- Mécaniques de réparation des canons

---

## 📄 Documentation

- [Mode opératoire Git](docs/MODE_OPERATOIRE_GIT.md)
- [Mode opératoire Installation](docs/MODE_OPERATOIRE_INSTALLATION.md)

---

## 📜 Licence

Projet académique EPITA - SAE J3D 2025-2026

---

*Janvier 2026*
